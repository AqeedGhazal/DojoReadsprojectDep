from django.apps import AppConfig


class ReadsAppConfig(AppConfig):
    name = 'Reads_App'
